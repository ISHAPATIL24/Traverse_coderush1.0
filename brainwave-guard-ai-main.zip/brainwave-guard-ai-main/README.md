# Welcome to Brain-wave Monitor 

## Project info
This is the code for our Brain wave monitor platform(Med-Tech) frontend with fundamentals features: consists of  Patient and Doctor Dashboard under which data is stored in form of list, graphs and table.





